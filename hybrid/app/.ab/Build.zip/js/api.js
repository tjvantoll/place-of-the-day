define([ "Everlive", "kendo.data.everlive" ], function( Everlive ) {
	"use strict";
	return new Everlive( "lLGSjm76TzCGSDza" );
});
